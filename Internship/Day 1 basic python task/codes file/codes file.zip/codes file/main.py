# main.py

import calculator

print("Addition =", calculator.add(10, 5))
print("Subtraction =", calculator.subtract(10, 5))